async function loginUser(event) {
    event.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    const response = await fetch('http://localhost:5000/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    });

    const result = await response.json();
    if (result.success) {
        localStorage.setItem('token', result.token);
        window.location.href = "C:\Users\Dell\OneDrive - Amrita Vishwa Vidyapeetham\Desktop\E-COMM\frontend\home.html";
    } else {
        alert(result.message);
    }
}
