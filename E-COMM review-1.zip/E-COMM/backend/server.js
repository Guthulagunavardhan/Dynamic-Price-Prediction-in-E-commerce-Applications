const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('./db');  // Database connection file
const nodemailer = require('nodemailer');

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

const otpStorage = {};  // Temporary storage for OTPs

// --------------------------
// 🚀 1️⃣ User Registration
// --------------------------
app.post("/register", async (req, res) => {
  const { firstname, lastname, email, password } = req.body;

  if (!firstname || !lastname || !email || !password) {
      return res.status(400).json({ message: "All fields are required" });
  }

  db.query("SELECT * FROM users WHERE email = ?", [email], async (err, results) => {
      if (err) return res.status(500).json({ message: "Database error" });

      if (results.length > 0) {
          return res.status(400).json({ message: "User already exists" });
      }

      try {
          const hashedPassword = await bcrypt.hash(password, 10);
          db.query(
              "INSERT INTO users (email, password, firstname, lastname) VALUES (?, ?, ?, ?)",
              [email, hashedPassword, firstname, lastname],
              (err, result) => {
                  if (err) return res.status(500).json({ message: "Registration error" });

                  res.json({ success: true, message: "User registered successfully" });
              }
          );
      } catch (error) {
          res.status(500).json({ message: "Error hashing password" });
      }
  });
});
// --------------------------
// 🚀 2️⃣ User Login
// --------------------------
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
  
    if (!email || !password) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    db.query("SELECT * FROM users WHERE email = ?", [email], async (err, results) => {
        if (err || results.length === 0) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        const user = results[0];
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        const token = jwt.sign(
            { userId: user.id, email: user.email },
            process.env.JWT_SECRET || 'SECRET_KEY',
            { expiresIn: '1h' }
        );

        res.json({ success: true, token, redirect: '/home.html' });
    });
});

// --------------------------
// 🚀 3️⃣ Forgot Password (Send OTP)
// --------------------------
const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_USER, // Your Gmail
        pass: process.env.EMAIL_PASS  // Your Gmail App Password
    }
});

app.post('/forgot-password', async (req, res) => {
  const { email } = req.body;

  if (!email) return res.status(400).json({ message: 'Email is required' });

  // Generate OTP
  const otp = Math.floor(100000 + Math.random() * 900000);
  otpStorage[email] = otp; // Save OTP temporarily

  const mailOptions = {
      from: process.env.EMAIL_USER,
      to: email,
      subject: "Password Reset OTP",
      text: `Your OTP is ${otp}. It is valid for 10 minutes.`
  };

  try {
      await transporter.sendMail(mailOptions);
      console.log(`✅ OTP sent to ${email}: ${otp}`);
      res.json({ success: true, message: 'OTP sent to your email' });
  } catch (error) {
      console.error("❌ Error sending OTP:", error);
      res.status(500).json({ message: 'Failed to send OTP' });
  }
});

// --------------------------
// 🚀 4️⃣ Verify OTP
// --------------------------

// ✅ API to Verify OTP
app.post('/verify-otp', (req, res) => {
    const { email, otp } = req.body;

    if (!email || !otp) {
        return res.status(400).json({ message: 'Email and OTP are required' });
    }

    console.log(`🔍 Checking OTP for ${email}: Sent OTP = ${otpStorage[email]}, User Entered = ${otp}`);

    if (otpStorage[email] && otpStorage[email] == otp) {
        delete otpStorage[email];  // ✅ Remove OTP after successful verification
        res.json({ success: true, message: 'OTP Verified' });
    } else {
        res.status(400).json({ message: 'Invalid OTP' });
    }
});


// --------------------------
// 🚀 5️⃣ Reset Password
// --------------------------
app.post('/reset-password', async (req, res) => {
    const { email, newPassword } = req.body;

    if (!email || !newPassword) {
        return res.status(400).json({ message: 'All fields are required' });
    }

    try {
        const hashedPassword = await bcrypt.hash(newPassword, 10);

        db.query("UPDATE users SET password = ? WHERE email = ?", [hashedPassword, email], (err, result) => {
            if (err) return res.status(500).json({ message: 'Server error' });

            res.json({ success: true, message: 'Password updated successfully' });
        });
    } catch (error) {
        res.status(500).json({ message: 'Error hashing password' });
    }
});

// --------------------------
// 🚀 6️⃣ Fetch Products (For E-commerce Store)
// --------------------------
app.get('/products', (req, res) => {
    db.query("SELECT * FROM products", (err, results) => {
        if (err) {
            return res.status(500).json({ message: 'Error fetching products' });
        }
        res.json(results);
    });
});

// --------------------------
// 🚀 Start Server
// --------------------------
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
